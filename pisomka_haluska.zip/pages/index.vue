<script setup></script>

<template>
  <div>
    <h1>HOME</h1>
    <div><NuxtLink to="/classes">tu</NuxtLink></div>
  </div>
</template>

<style scoped></style>
